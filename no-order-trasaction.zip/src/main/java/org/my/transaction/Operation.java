package org.my.transaction;

public enum Operation {
	INSERT,
	UPDATE,
	CANCEL
}
