package org.my.transaction;

public class Trade  implements Comparable<Trade>
{
	
	 
	private int tradeId;
	private int version;
	private String securityCode;
	private int qauntity;
	private  String oper ; //INSERT ...
	private  String dirct ; //Buy/Sell
	private boolean done=false; //false pending
	 
	public Trade(int tradeId, int version, String securityCode, int qauntity, String oper, String dirct) {
		super();
		this.tradeId = tradeId;
		this.version = version;
		this.securityCode = securityCode;
		this.qauntity = qauntity;
		this.oper = oper;
		this.dirct = dirct;
	}
	public boolean isDone() {
		return done;
	}
	public void setDone(boolean done) {
		this.done = done;
	}
	public int getTradeId() {
		return tradeId;
	}
	public void setTradeId(int tradeId) {
		this.tradeId = tradeId;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getSecurityCode() {
		return securityCode;
	}
	public void setSecurityCode(String securityCode) {
		this.securityCode = securityCode;
	} 
	
	public int getQauntity() {
		return qauntity;
	}
	public void setQauntity(int qauntity) {
		this.qauntity = qauntity;
	}
	public String getOper() {
		return oper;
	}
	public void setOper(String oper) {
		this.oper = oper;
	}
	public String getDirct() {
		return dirct;
	}
	public void setDirct(String dirct) {
		this.dirct = dirct;
	}
	 
	@Override
	public int compareTo(Trade o) { 
		if(o.getTradeId()==this.getTradeId())
		{
			return this.version - o.getVersion() ;
		}else
		{
			return this.getTradeId() -o.getTradeId();
		}
	
	}
	@Override
	public String toString() {
		return "Trade [tradeId=" + tradeId + ", version=" + version + ", securityCode=" + securityCode + ", qauntity="
				+ qauntity + ", oper=" + oper + ", dirct=" + dirct + ", done=" + done + "]";
	}
 
	
}