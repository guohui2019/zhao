package org.my.transaction;

import java.util.ArrayList;
import java.util.List;

 
public class TradeDao {
	 private List<Trade> db=new ArrayList<>();
	 
	 public void add (Trade trade)
	 {
		 db.add(trade);
	 }
	 public Trade  getMaxVersionByTradeId(int tradeId) 
	 {
		 Trade res=null;
		 for(Trade t:db)
		 {
			 if(tradeId==t.getTradeId())
			 {
				 if(res==null)
					 res=t;
				 else  if(res.getVersion()<t.getVersion())
				 {
					 res=t;
				 }
			 }
		 }
		 return res;
	 }
	 public Trade  getByTradeIdAndVersion(int tradeId,int version) 
	 {
		 Trade res=null;
		 for(Trade t:db)
		 {
			 if(tradeId==t.getTradeId() && t.getVersion()==version)
			 {
				return t;
			 }
		 }
		 return res;
	 }
	 
	 public List<Trade>   queryAllUnDone( ) 
	 {
		 List<Trade> unDone=new ArrayList<>();
		 for(Trade t:db)
		 {
			 if(t.isDone()==false)
			 {
				 unDone.add(t);
			 }
		 }
		 return unDone;
	 }
	 public void updateDoneByTradeIdAndVersionId(int tradeId,int versionId)
	 {
		 for(Trade t:db)
		 {
			 if(t.getTradeId()==tradeId && t.getVersion() ==versionId )
			 {
				 t.setDone(true);
			 }
		 }
		 
	 }
	 public boolean isHaveCancelByTradeId(int tradeId)
	 {
		 for(Trade t:db)
		 {
			 if(t.getTradeId()==tradeId && t.isDone()==true && t.getOper()  == Operation.CANCEL.name() )
			 {
				return true;
			 }
		 }
		 return false;
	 }
}
