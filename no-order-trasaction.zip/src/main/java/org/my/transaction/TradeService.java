package org.my.transaction;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

 
public class TradeService {
	private TradeDao dao=new TradeDao();
	 
	 /* Key=SecurityCode,Value is amount */
	 Map<String,Integer> securityAmount=new HashMap<>();

	 public Map<String,Integer> getSecurityAmount() {
		 return securityAmount;
	 }
	 public void  receiveRade(Trade trade) throws Exception 
	 {
		 if(dao.isHaveCancelByTradeId(trade.getTradeId()))
		 {
			 throw new Exception("already have cancel operation");
		 }
		 execute(trade);
		 processUnDone();
	 }
	 private void execute(Trade trade ) throws Exception
	 {
		 if(trade.getOper().equals(Operation.INSERT.name()) ) 
		 {
			 insertSecurityAccount(trade);
		 } else if (trade.getOper().equals(Operation.UPDATE.name()) )
		 {
			 updateSecurityAccount(trade);
		 }else  if (trade.getOper().equals(Operation.CANCEL.name()) )
		 {
			 cancelSecurityAccount(trade);
		 }
	 }
	
	 private void processUnDone()
	 {
		 List<Trade> allUnDone = dao.queryAllUnDone();
		 Collections.sort(allUnDone);
		 allUnDone.forEach(trade->{
			 Trade previous=dao.getByTradeIdAndVersion(trade.getTradeId(),trade.getVersion()-1);
			 if(previous!=null && previous.isDone()==true)
			 {
				 try {
					 execute(trade);
				} catch (Exception e) {
					e.printStackTrace();
				}
			 }
		 });
	 }
	
	 private void  insertSecurityAccount(Trade trade) throws Exception  
	 {
		 if(trade.getVersion()!=1)
			 throw new Exception("insert operation ,version is not 1");
		 
		 dao.add(trade); 
		 int direct =trade.getDirct().equals(Direction.Buy.name())? 1 : -1 ;
		 
		 Integer newAmount=0;
		 if(securityAmount.get(trade.getSecurityCode())==null)
		 {
			newAmount= trade.getQauntity()*direct;
			 
		 }else
		 {
			 newAmount=  securityAmount.get(trade.getSecurityCode())+trade.getQauntity()*direct; 
			 
		 }
		 securityAmount.put(trade.getSecurityCode(), newAmount);
		 dao.updateDoneByTradeIdAndVersionId(trade.getTradeId(),trade.getVersion());
	 }

	 private void  updateSecurityAccount(Trade trade) 
	 {  
		 Trade last=dao.getMaxVersionByTradeId(trade.getTradeId());
		 dao.add(trade); 
		 if(last==null || trade.getVersion() != last.getVersion()+1 )
		 {
			 return; 
		 }
		 
		 int direct =trade.getDirct().equals(Direction.Buy.name())? 1 : -1 ;
		 //update security
 		 securityAmount.put(trade.getSecurityCode(),trade.getQauntity()*direct) ; 
 		 dao.updateDoneByTradeIdAndVersionId(trade.getTradeId(),trade.getVersion());
 		 
 		 
	 }
	 private void cancelSecurityAccount(Trade trade) throws Exception  {
		
		 Trade last= dao.getMaxVersionByTradeId(trade.getTradeId()); 
		  if(last==null)
		  {
			 throw new Exception("cancel is first version");  
		  }
		  
		  if(trade.getVersion()>last.getVersion()+1)
		  {
			  dao.add(trade); 
			  return;
		  }
		  Trade second= dao.getByTradeIdAndVersion(trade.getTradeId(), last.getVersion()-1);
		  dao.add(trade); 
		  if(second==null)
		  {
			  securityAmount.put(trade.getSecurityCode(), 0) ;
		  }else
		  {
			  securityAmount.put(trade.getSecurityCode(), second.getQauntity()) ;
		  }
		
		  dao.updateDoneByTradeIdAndVersionId(trade.getTradeId(),trade.getVersion());
	 }
	 
}
