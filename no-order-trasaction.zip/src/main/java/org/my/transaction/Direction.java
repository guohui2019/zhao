package org.my.transaction;

public enum Direction {
	Buy,
	Sell  
}
