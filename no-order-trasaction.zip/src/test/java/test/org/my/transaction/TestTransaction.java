package test.org.my.transaction;

import org.junit.jupiter.api.Test;
import org.my.transaction.Direction;
import org.my.transaction.Operation;
import org.my.transaction.Trade;
import org.my.transaction.TradeService;

import static org.junit.jupiter.api.Assertions.*; 

public class TestTransaction {
	
	@Test
	public void testExample() throws Exception
	{
		TradeService service=new TradeService();
    	service.receiveRade(new Trade(1, 1,"REL",50,Operation.INSERT.name(),Direction.Buy.name()));
    	service.receiveRade(new Trade(2, 1,"ITC",40,Operation.INSERT.name(),Direction.Sell.name()));
    	service.receiveRade(new Trade(3, 1,"INF",70,Operation.INSERT.name(),Direction.Buy.name()));
    	
    	service.receiveRade(new Trade(1, 2,"REL",60,Operation.UPDATE.name(),Direction.Buy.name()));
    	service.receiveRade(new Trade(2, 2,"ITC",30,Operation.CANCEL.name(),Direction.Buy.name()));
    	service.receiveRade(new Trade(4, 1,"INF",20,Operation.INSERT.name(),Direction.Sell.name()));
    	
    	assertEquals(3,   service.getSecurityAmount().size() );
    	assertEquals(60,   service.getSecurityAmount().get("REL") );
    	assertEquals(0,   service.getSecurityAmount().get("ITC") );
    	assertEquals(50,   service.getSecurityAmount().get("INF") );
    	
    	System.out.println(service.getSecurityAmount());
	}
	@Test
	public void testInsertVersion1Throws() throws Exception
	{
    	assertThrows(Exception.class,  ()->{
    		TradeService service=new TradeService();
        	service.receiveRade( new Trade(1,2,"REL",50,Operation.INSERT.name(),Direction.Buy.name()));
    	});
    	 
	}
	@Test
	public void testCancelThrows() throws Exception
	{
    	assertThrows(Exception.class,  ()->{
    		TradeService service=new TradeService();
			service.receiveRade( new Trade(1,1,"REL",50,Operation.INSERT.name(),Direction.Buy.name()));
	    	service.receiveRade( new Trade(1,2,"REL",50,Operation.CANCEL.name(),Direction.Buy.name()));
	    	service.receiveRade( new Trade(1,3,"REL",50,Operation.UPDATE.name(),Direction.Buy.name()));
    	});
    	 
	}
	@Test
	public void testVersionNormal() throws Exception
	{
		TradeService service=new TradeService();
    	service.receiveRade( new Trade(1,1,"REL",50,Operation.INSERT.name(),Direction.Buy.name())); 
    	service.receiveRade( new Trade(1,2,"REL",60,Operation.UPDATE.name(),Direction.Sell.name()));
    	service.receiveRade( new Trade(1,3,"REL",30,Operation.CANCEL.name(),Direction.Buy.name())); 
    	
    	assertEquals(50,   service.getSecurityAmount().get("REL") ); 
    	 
	}
	@Test
	public void testVersionNoOrder() throws Exception
	{
		TradeService service=new TradeService();
    	service.receiveRade( new Trade(1,1,"REL",50,Operation.INSERT.name(),Direction.Buy.name())); 
    	service.receiveRade( new Trade(1,3,"REL",30,Operation.CANCEL.name(),Direction.Buy.name())); 
    	service.receiveRade( new Trade(1,2,"REL",60,Operation.UPDATE.name(),Direction.Sell.name()));
    	
    	
    	assertEquals(50,   service.getSecurityAmount().get("REL") ); 
    	 
	}
}
